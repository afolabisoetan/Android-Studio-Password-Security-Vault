package com.example.assignment2;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        TextView textView = findViewById(R.id.textView);
        textView.setText("Full Name: XYZ\nStudent ID: XXXXX");

        Button explicitButton = findViewById(R.id.button_explicit);
        Button implicitButton = findViewById(R.id.button_implicit);

        Button image = findViewById(R.id.button_image);

        image.setOnClickListener(V ->
        {
            Intent imageIntent = new Intent(MainActivity.this, ImageActivity.class);
            startActivity(imageIntent);
        });

        explicitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (ContextCompat.checkSelfPermission(MainActivity.this, "com.example.assignment2.MSE412") == PackageManager.PERMISSION_GRANTED) {

                    Intent explicitIntent = new Intent(MainActivity.this, SecondActivity.class);
                    startActivity(explicitIntent);

                } else {

                    ActivityCompat.requestPermissions(MainActivity.this,
                            new String[]{"com.example.assignment2.MSE412"}, 1);
                }
            }
        });

        implicitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent implicitIntent = new Intent("com.example.assignment2.OPEN_SECOND_ACTIVITY");
                startActivity(implicitIntent);
            }
        });
    }
}
