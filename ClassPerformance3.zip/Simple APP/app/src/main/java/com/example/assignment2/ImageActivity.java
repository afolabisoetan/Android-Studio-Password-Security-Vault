package com.example.assignment2;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import com.bumptech.glide.Glide;

import java.io.File;
import java.io.IOException;

public class ImageActivity extends AppCompatActivity {

    ImageView image;
    Uri photoUri;

    private static final int CAMERA_CODE = 1001;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_image);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        Button back = findViewById(R.id.Back);
        Button camera = findViewById(R.id.camera);
        image = findViewById(R.id.click_image);



        camera.setOnClickListener(v ->
        {
            try{
                File photoFilePath = createImageFile();
                photoUri = FileProvider.getUriForFile(this, getPackageName() + ".fileprovider", photoFilePath);
                Intent cameraIntent = new Intent (MediaStore.ACTION_IMAGE_CAPTURE);
                cameraIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoUri);
                cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                startActivityForResult(cameraIntent, CAMERA_CODE);

            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        });

        back.setOnClickListener(v ->
        {
            Intent goBack = new Intent(ImageActivity.this, MainActivity.class);
            startActivity(goBack);
        });
    }

    private File createImageFile() throws IOException {
        File imageDir = new File (getCacheDir(), "cached_images");
        if(!imageDir.exists())
        {
            imageDir.mkdir();
        }

        return File.createTempFile("captured_", ".jpg", imageDir);
    }

    @Override
    @Deprecated
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data)
    {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CAMERA_CODE && resultCode == RESULT_OK)
        {
            Glide.with(this).load(photoUri).into(image);

        }
    }
}